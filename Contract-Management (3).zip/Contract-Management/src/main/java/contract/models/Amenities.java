package contract.models;

public class Amenities {

	private int id;
	private String atype;
	private String aminity;
	private int cid;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAtype() {
		return atype;
	}
	public void setAtype(String atype) {
		this.atype = atype;
	}
	public String getAminity() {
		return aminity;
	}
	public void setAminity(String aminity) {
		this.aminity = aminity;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	
	
}
