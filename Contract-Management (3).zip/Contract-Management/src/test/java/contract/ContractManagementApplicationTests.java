package contract;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContractManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
